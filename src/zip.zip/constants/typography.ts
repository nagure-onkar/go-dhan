const typography = {
  fontRegular: 'System',
  fontMedium: 'System',
  fontBold: 'System',

  sizeSmall: 12,
  sizeMedium: 16,
  sizeLarge: 20,
  sizeXL: 24,
};

export default typography;
