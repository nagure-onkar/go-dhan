export default {
  menu: 'Menu',
  settings: 'Settings',
  changeLanguage: 'Change Language',
  home: 'Home',
  lactation: 'Lactation',
  feed: 'Feed',
  profit: 'Profit'
};
