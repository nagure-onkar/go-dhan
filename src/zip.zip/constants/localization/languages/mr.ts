export default {
  menu: 'मेनू',
  settings: 'सेटिंग्स',
  changeLanguage: 'भाषा बदला',
  home: 'मुख्यपृष्ठ',
  lactation: 'दुधकाढणी',
  feed: 'चरापाणी',
  profit: 'नफा'
};
